$.fn.flagy = function() {
    return this.each(function() {

        $(this).click(function(){
            this.set_data();
        });

        this.set_data = function(){
            alert($(this).attr('data-a'));
        }

    });
};

